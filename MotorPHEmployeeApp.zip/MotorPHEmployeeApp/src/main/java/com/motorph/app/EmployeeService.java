package com.motorph.app;

import java.util.ArrayList;
import java.util.List;

public class EmployeeService {
    private final List<Employee> employees = new ArrayList<>();
    private int nextId = 1;

    public void addEmployee(String name, String position) {
        if (name == null || name.isEmpty() || position == null || position.isEmpty()) {
            System.out.println("⚠️ Name and position must not be empty.");
            return;
        }
        Employee emp = new Employee(nextId++, name.trim(), position.trim());
        employees.add(emp);
        System.out.println("✅ Employee added.");
    }

    public void viewEmployees() {
        if (employees.isEmpty()) {
            System.out.println("📭 No employee records found.");
        } else {
            System.out.println("\n--- Employee Records ---");
            employees.forEach(System.out::println);
        }
    }
}
